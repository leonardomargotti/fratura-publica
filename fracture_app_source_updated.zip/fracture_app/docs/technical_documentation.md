# Documentação Técnica - Aplicativo de Classificação de Fraturas Ortopédicas

## Visão Geral da Arquitetura

O Aplicativo de Classificação de Fraturas Ortopédicas foi desenvolvido utilizando Flutter como framework principal, permitindo a criação de uma aplicação multiplataforma que funciona tanto em Android quanto em iOS. A arquitetura do aplicativo segue o padrão de design orientado a modelos, com separação clara entre dados, lógica de negócios e interface do usuário.

### Componentes Principais

1. **Interface do Usuário (UI)**
   - Implementada com widgets Flutter
   - Design responsivo para diferentes tamanhos de tela
   - Suporte a temas claro e escuro
   - Componentes reutilizáveis para consistência visual

2. **Lógica de Negócios**
   - Gerenciamento de estado com Provider
   - Serviços para operações específicas (conectividade, sincronização)
   - Controladores para cada funcionalidade principal

3. **Camada de Dados**
   - Banco de dados SQLite local para armazenamento offline
   - Modelos de dados para representar entidades do domínio
   - Gerenciador de banco de dados para operações CRUD
   - Sistema de sincronização para atualização de dados quando online

4. **Funcionalidade Offline**
   - Detecção de conectividade
   - Armazenamento local de dados e imagens
   - Fila de operações para sincronização posterior
   - Indicador visual do estado de conectividade

## Estrutura de Diretórios

```
lib/
├── database/
│   └── database_helper.dart
├── models/
│   ├── models.dart (exportação de todos os modelos)
│   ├── osso.dart
│   ├── sistema_classificacao.dart
│   ├── tipo_fratura.dart
│   ├── tratamento.dart
│   ├── conduta.dart
│   ├── imagem.dart
│   ├── parametro_classificacao.dart
│   ├── valor_parametro.dart
│   ├── regra_classificacao.dart
│   └── historico_classificacao.dart
├── screens/
│   ├── home_screen.dart
│   ├── select_bone_screen.dart
│   ├── fracture_parameters_screen.dart
│   ├── classification_results_screen.dart
│   ├── classification_details_screen.dart
│   ├── treatment_details_screen.dart
│   ├── database_query_screen.dart
│   └── references_screen.dart
├── utils/
│   ├── app_constants.dart
│   ├── app_theme.dart
│   ├── connectivity_service.dart
│   ├── offline_manager.dart
│   └── sync_manager.dart
└── main.dart
```

## Banco de Dados

O banco de dados SQLite local contém as seguintes tabelas:

1. **Ossos**: Armazena informações sobre os ossos do corpo humano
2. **SistemasClassificacao**: Contém os diferentes sistemas de classificação (AO/OTA, Salter-Harris, etc.)
3. **TiposFratura**: Armazena os tipos específicos de fratura dentro de cada sistema
4. **Imagens**: Contém imagens representativas para cada tipo de fratura
5. **Tratamentos**: Armazena tratamentos recomendados para cada tipo de fratura
6. **Condutas**: Contém procedimentos passo a passo para cada tratamento
7. **ParametrosClassificacao**: Define os parâmetros utilizados para classificar fraturas
8. **ValoresParametros**: Armazena os possíveis valores para cada parâmetro
9. **RegrasClassificacao**: Define as regras para classificar fraturas com base nos parâmetros
10. **HistoricoClassificacoes**: Armazena o histórico de classificações realizadas pelo usuário
11. **SincronizacaoInfo**: Contém informações sobre o estado de sincronização

## Fluxo de Dados

1. **Classificação de Fraturas**:
   - O usuário seleciona um osso e fornece parâmetros da fratura
   - O aplicativo consulta o banco de dados local usando as regras de classificação
   - Os resultados são exibidos ao usuário, incluindo classificações, imagens e tratamentos
   - A classificação é salva no histórico local
   - Se online, a classificação é sincronizada com o servidor

2. **Consulta ao Banco de Dados**:
   - O usuário pode pesquisar diretamente no banco de dados
   - Os resultados são filtrados com base nos critérios de pesquisa
   - O usuário pode visualizar detalhes completos de qualquer classificação

3. **Sincronização de Dados**:
   - Quando online, o aplicativo verifica se há atualizações disponíveis
   - Novas classificações, imagens ou tratamentos são baixados
   - Operações pendentes são enviadas ao servidor
   - O estado de sincronização é atualizado

## Modelos de Dados

### Osso
```dart
class Osso {
  final int id;
  final String nome;
  final String regiao;
  final String? descricao;
  
  // Construtor e métodos de conversão Map/Object
}
```

### SistemaClassificacao
```dart
class SistemaClassificacao {
  final int id;
  final String nome;
  final String? descricao;
  final String? referencia;
  
  // Construtor e métodos de conversão Map/Object
}
```

### TipoFratura
```dart
class TipoFratura {
  final int id;
  final int? ossoId;
  final int sistemaId;
  final String codigo;
  final String nome;
  final String? descricao;
  final String? caracteristicas;
  
  Osso? osso;
  SistemaClassificacao? sistema;
  
  // Construtor e métodos de conversão Map/Object
}
```

## Funcionalidade Offline

### OfflineManager
Responsável pelo gerenciamento do banco de dados SQLite local:
- Inicialização do banco de dados
- Criação de tabelas
- População com dados iniciais
- Armazenamento e recuperação de imagens
- Gerenciamento do histórico de classificações

### ConnectivityService
Monitora o estado de conectividade do dispositivo:
- Detecção de mudanças de conectividade (WiFi, dados móveis, offline)
- Notificação de mudanças de estado para outros componentes
- Exibição de banner indicando o estado atual de conectividade

### SyncManager
Gerencia a sincronização de dados entre o dispositivo e o servidor:
- Armazenamento de operações pendentes quando offline
- Sincronização automática quando online
- Gerenciamento de conflitos
- Rastreamento do estado de sincronização

## Testes

O aplicativo inclui os seguintes tipos de testes:

1. **Testes de Funcionalidade**:
   - Verificação da inicialização do aplicativo
   - Testes de inicialização do banco de dados
   - Testes de consulta de dados
   - Testes de navegação entre telas

2. **Testes de Precisão da Classificação**:
   - Verificação da precisão das classificações de fraturas
   - Testes de correspondência entre parâmetros e classificações
   - Testes de tratamentos recomendados

3. **Testes de Funcionalidade Offline**:
   - Verificação do funcionamento sem conexão
   - Testes de armazenamento local
   - Testes de sincronização quando online

## Requisitos de Sistema

### Android
- Android 5.0 (API nível 21) ou superior
- 100 MB de espaço de armazenamento disponível
- 2 GB de RAM recomendado

### iOS
- iOS 11.0 ou superior
- 100 MB de espaço de armazenamento disponível
- iPhone 6s ou superior recomendado

## Considerações de Segurança

- Os dados são armazenados localmente no dispositivo do usuário
- Não há coleta de informações pessoais de pacientes
- O banco de dados local é criptografado
- As comunicações com o servidor (quando implementadas) devem usar HTTPS

## Limitações Conhecidas

- O aplicativo atualmente não sincroniza com um servidor remoto (funcionalidade planejada para versões futuras)
- As imagens incluídas são representativas e não cobrem todas as variações possíveis de fraturas
- A classificação automática deve ser sempre confirmada por um profissional qualificado

## Planos Futuros

- Implementação de um servidor backend para sincronização de dados
- Adição de mais sistemas de classificação
- Inclusão de mais imagens e exemplos de casos
- Implementação de inteligência artificial para auxiliar na classificação
- Suporte a múltiplos idiomas

## Referências Técnicas

- Flutter: https://flutter.dev/docs
- SQLite: https://www.sqlite.org/docs.html
- Provider (gerenciamento de estado): https://pub.dev/packages/provider
- Connectivity Plus: https://pub.dev/packages/connectivity_plus
- Shared Preferences: https://pub.dev/packages/shared_preferences
