# README - Aplicativo de Classificação de Fraturas Ortopédicas

## Visão Geral

O Aplicativo de Classificação de Fraturas Ortopédicas é uma ferramenta desenvolvida para auxiliar profissionais de saúde na classificação de fraturas, fornecendo informações precisas sobre os diversos sistemas de classificação, imagens de exemplo, tratamentos recomendados e condutas médicas.

Este aplicativo foi desenvolvido utilizando Flutter, permitindo sua execução tanto em dispositivos Android quanto iOS, e inclui funcionalidade offline completa para uso em ambientes sem conexão com a internet.

## Funcionalidades Principais

- **Classificação de Fraturas**: Classifique fraturas com base em parâmetros como osso afetado, tipo de traço, exposição, idade do paciente, etc.
- **Múltiplos Sistemas de Classificação**: Inclui os principais sistemas como AO/OTA, Salter-Harris, Neer, Weber, Garden e Schatzker.
- **Banco de Dados Completo**: Consulte diretamente o banco de dados de classificações ortopédicas.
- **Imagens de Exemplo**: Visualize imagens representativas para cada tipo de fratura.
- **Tratamentos Recomendados**: Obtenha recomendações de tratamento e condutas médicas.
- **Funcionalidade Offline**: Funciona completamente sem conexão com a internet.
- **Sincronização**: Sincroniza dados automaticamente quando online.

## Estrutura do Projeto

```
fracture_app/
├── database/            # Scripts SQL e esquema do banco de dados
├── docs/                # Documentação do projeto
│   ├── deployment_instructions.md
│   ├── technical_documentation.md
│   └── user_manual.md
├── prototype/           # Código-fonte do aplicativo Flutter
│   ├── lib/
│   │   ├── database/    # Helpers para acesso ao banco de dados
│   │   ├── models/      # Modelos de dados
│   │   ├── screens/     # Telas do aplicativo
│   │   ├── utils/       # Utilitários e serviços
│   │   └── main.dart    # Ponto de entrada do aplicativo
│   └── test/            # Testes automatizados
└── research/            # Pesquisa e referências
```

## Documentação

O projeto inclui a seguinte documentação:

1. **Manual do Usuário** (`docs/user_manual.md`): Guia completo para usuários finais, incluindo instruções de instalação e uso.
2. **Documentação Técnica** (`docs/technical_documentation.md`): Detalhes técnicos sobre a arquitetura, banco de dados, modelos de dados e funcionalidades.
3. **Instruções de Implantação** (`docs/deployment_instructions.md`): Guia passo a passo para compilar e publicar o aplicativo nas lojas de aplicativos.

## Requisitos de Sistema

### Para Desenvolvimento
- Flutter SDK (versão 3.0.0 ou superior)
- Dart SDK (versão 2.17.0 ou superior)
- Android Studio (para desenvolvimento Android)
- Xcode (para desenvolvimento iOS, apenas em macOS)

### Para Usuários Finais
- **Android**: Android 5.0 (API nível 21) ou superior
- **iOS**: iOS 11.0 ou superior
- 100 MB de espaço de armazenamento disponível

## Instalação para Desenvolvimento

1. Clone o repositório:
```
git clone https://github.com/seu-usuario/fracture-app.git
cd fracture-app
```

2. Instale as dependências:
```
cd prototype
flutter pub get
```

3. Execute o aplicativo:
```
flutter run
```

Para instruções detalhadas sobre compilação e publicação, consulte o arquivo `docs/deployment_instructions.md`.

## Testes

O projeto inclui testes automatizados para verificar a funcionalidade e precisão do aplicativo:

```
cd prototype
flutter test
```

## Limitações e Avisos

- Este aplicativo é uma ferramenta de auxílio e não substitui o julgamento clínico de um profissional de saúde qualificado.
- As classificações e tratamentos sugeridos devem ser sempre confirmados por um profissional.
- As imagens incluídas são representativas e não cobrem todas as variações possíveis de fraturas.

## Contribuições

Contribuições são bem-vindas! Se você deseja contribuir com este projeto, por favor:

1. Faça um fork do repositório
2. Crie uma branch para sua feature (`git checkout -b feature/nova-feature`)
3. Faça commit das suas mudanças (`git commit -m 'Adiciona nova feature'`)
4. Faça push para a branch (`git push origin feature/nova-feature`)
5. Abra um Pull Request

## Licença

Este projeto está licenciado sob a licença MIT - veja o arquivo LICENSE para detalhes.

## Contato

Para suporte técnico ou dúvidas sobre o aplicativo, entre em contato através de:
- Email: suporte@classificadorfraturas.com
