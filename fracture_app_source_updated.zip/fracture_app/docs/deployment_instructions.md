# Instruções de Implantação - Aplicativo de Classificação de Fraturas Ortopédicas

Este documento contém as instruções para implantar o aplicativo de Classificação de Fraturas Ortopédicas em dispositivos Android e iOS, tanto para desenvolvimento quanto para produção.

## Pré-requisitos

### Ambiente de Desenvolvimento
- Flutter SDK (versão 3.0.0 ou superior)
- Dart SDK (versão 2.17.0 ou superior)
- Android Studio (para desenvolvimento Android)
- Xcode (para desenvolvimento iOS, apenas em macOS)
- Git

### Dispositivos/Emuladores
- Emulador Android ou dispositivo físico Android
- Simulador iOS ou dispositivo físico iOS (apenas em macOS)

### Contas de Desenvolvedor
- Conta de desenvolvedor Google Play (para publicação na Google Play Store)
- Conta de desenvolvedor Apple (para publicação na App Store)

## Configuração do Ambiente de Desenvolvimento

### Instalação do Flutter
1. Baixe o Flutter SDK do site oficial: https://flutter.dev/docs/get-started/install
2. Extraia o arquivo baixado para um local de sua preferência (evite caminhos com espaços ou caracteres especiais)
3. Adicione o diretório `flutter/bin` ao seu PATH
4. Execute `flutter doctor` para verificar se há dependências adicionais a serem instaladas

### Configuração para Android
1. Instale o Android Studio: https://developer.android.com/studio
2. Instale o Android SDK através do Android Studio
3. Configure um emulador Android ou conecte um dispositivo físico
4. Execute `flutter doctor --android-licenses` para aceitar as licenças do Android

### Configuração para iOS (apenas macOS)
1. Instale o Xcode através da App Store
2. Instale as ferramentas de linha de comando do Xcode: `xcode-select --install`
3. Configure um simulador iOS ou conecte um dispositivo físico
4. Execute `sudo gem install cocoapods` para instalar o CocoaPods

## Obtendo o Código-Fonte

1. Clone o repositório do projeto:
```
git clone https://github.com/seu-usuario/fracture-app.git
cd fracture-app
```

2. Instale as dependências do projeto:
```
flutter pub get
```

## Executando o Aplicativo em Modo de Desenvolvimento

### Android
1. Conecte um dispositivo Android ou inicie um emulador
2. Execute o aplicativo:
```
flutter run
```

### iOS (apenas macOS)
1. Conecte um dispositivo iOS ou inicie um simulador
2. Execute o aplicativo:
```
flutter run
```

## Preparando o Aplicativo para Produção

### Configuração do Arquivo pubspec.yaml
1. Atualize a versão do aplicativo no arquivo `pubspec.yaml`:
```yaml
version: 1.0.0+1  # Formato: [versão].[subversão].[patch]+[número da build]
```

### Configuração do Ícone e Splash Screen
1. Substitua os ícones padrão em:
   - `android/app/src/main/res/mipmap-*` para Android
   - `ios/Runner/Assets.xcassets/AppIcon.appiconset` para iOS
2. Configure a splash screen em:
   - `android/app/src/main/res/drawable/launch_background.xml` para Android
   - `ios/Runner/Assets.xcassets/LaunchImage.imageset` para iOS

## Compilando para Produção

### Android
1. Crie uma chave para assinar o APK:
```
keytool -genkey -v -keystore ~/upload-keystore.jks -keyalg RSA -keysize 2048 -validity 10000 -alias upload
```

2. Crie o arquivo `android/key.properties` com o seguinte conteúdo:
```
storePassword=<senha do keystore>
keyPassword=<senha da chave>
keyAlias=upload
storeFile=<caminho para o arquivo upload-keystore.jks>
```

3. Configure a assinatura no arquivo `android/app/build.gradle`

4. Compile o APK:
```
flutter build apk --release
```
O APK será gerado em `build/app/outputs/flutter-apk/app-release.apk`

5. Alternativamente, compile um bundle Android App Bundle (recomendado para Google Play):
```
flutter build appbundle --release
```
O AAB será gerado em `build/app/outputs/bundle/release/app-release.aab`

### iOS (apenas macOS)
1. Atualize o arquivo `ios/Runner/Info.plist` com as informações do seu aplicativo

2. Compile o IPA:
```
flutter build ios --release
```

3. Abra o projeto Xcode:
```
open ios/Runner.xcworkspace
```

4. Em Xcode, selecione um dispositivo ou "Generic iOS Device"
5. Selecione Product > Archive
6. No organizador de arquivos, clique em "Distribute App"

## Publicação nas Lojas de Aplicativos

### Google Play Store
1. Acesse o Google Play Console: https://play.google.com/console
2. Crie um novo aplicativo
3. Preencha todas as informações necessárias (descrição, capturas de tela, etc.)
4. Faça upload do arquivo AAB gerado
5. Configure a classificação de conteúdo
6. Publique o aplicativo (pode levar algumas horas para revisão)

### Apple App Store
1. Acesse o App Store Connect: https://appstoreconnect.apple.com
2. Crie um novo aplicativo
3. Preencha todas as informações necessárias (descrição, capturas de tela, etc.)
4. Faça upload do arquivo IPA usando o Application Loader ou diretamente do Xcode
5. Configure a classificação de conteúdo
6. Envie para revisão (pode levar alguns dias)

## Distribuição Ad-Hoc (para testes)

### Android
1. Compile o APK:
```
flutter build apk --release
```
2. Distribua o arquivo APK diretamente para os testadores

### iOS (apenas macOS)
1. Configure os dispositivos de teste no portal de desenvolvedor Apple
2. Crie um perfil de provisionamento para distribuição ad-hoc
3. Compile o aplicativo com esse perfil
4. Distribua o arquivo IPA usando serviços como TestFlight ou Diawi

## Solução de Problemas Comuns

### Problemas de Compilação
- Limpe a pasta de build: `flutter clean`
- Atualize as dependências: `flutter pub get`
- Verifique se todas as dependências são compatíveis: `flutter pub outdated`

### Problemas de Execução
- Verifique se o dispositivo está conectado: `flutter devices`
- Reinicie o aplicativo com hot reload: pressione `r` no terminal
- Reinicie o aplicativo completamente: pressione `R` no terminal

### Problemas de Publicação
- Verifique se todas as informações necessárias foram preenchidas no console da loja
- Certifique-se de que o aplicativo atende às diretrizes da loja
- Verifique se a versão do aplicativo é maior que a versão anteriormente publicada

## Recursos Adicionais
- Documentação do Flutter: https://flutter.dev/docs
- Publicação na Google Play: https://developer.android.com/distribute/best-practices/launch
- Publicação na App Store: https://developer.apple.com/app-store/submissions/
